# One Connected Future — Andrea Ednie's Vision

An accessible, single-file, animated presentation webpage intended as a **proposal for discussion** with the UW–Whitewater provost. No dependencies, accounts, build step, analytics, or external assets are required.

## Open locally
Double-click `index.html` in a modern browser.

## Present
Click **Present to the provost** (or **Present** in the navigation). Use the **Next** and **Previous** controls, keyboard Right/Left arrows, Page Up/Down, or spacebar. Press Escape to exit presentation mode. Scroll normally if desired.

## Publish on GitHub Pages
1. Create a new GitHub repository (e.g. `andrea-grad-vision`).
2. Upload the `index.html` file to the repository root; commit the change.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, `main`, and `/(root)`. Save.
5. Visit the URL displayed in Pages settings after deployment.

## Adapt content
All text is in `index.html`. Search for `A proposed vision`, `The UWW Learning Innovation Collaborative`, or `A proposed provost-level invitation` to edit main copy. The page uses system fonts and inline SVG; no copyrighted photos or external image services are needed.

## Governance
The content describes **proposed** partnerships and pilot projects, not approved initiatives. Before deployment beyond a private demonstration, confirm institutional review, involved stakeholders, naming, accessibility, privacy, AI-tool safeguards, and ownership. No student records or private materials should be embedded in this public page.
